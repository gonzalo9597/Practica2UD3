create
    definer = root@localhost function existeNombreEditorial(f_name varchar(50)) returns bit
begin
	declare i int;
    set i = 0;
    while ( i < (select max(ideditorial) from editoriales)) do
    if  ((select nombre from editorial where ideditorial = (i + 1)) like f_name) then return 1;
    end if;
    set i = i + 1;
    end while;
    return 0;
end;

